// prisma.config.ts
import 'dotenv/config'; // загружает .env автоматически
import { defineConfig, env } from 'prisma/config';

export default defineConfig({
  schema: 'prisma/schema.prisma',          // путь к твоей схеме
  migrations: {
    path: 'prisma/migrations',             // куда сохранять миграции
  },
  datasource: {
    url: env('DATABASE_URL'),              // берёт из .env
  },
});