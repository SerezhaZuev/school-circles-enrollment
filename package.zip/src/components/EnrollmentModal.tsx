import React, { useState } from 'react';
import { Button } from './ui/Button';
import { X } from 'lucide-react';
interface EnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (comment: string) => void;
  sectionName: string;
}
export function EnrollmentModal({
  isOpen,
  onClose,
  onConfirm,
  sectionName
}: EnrollmentModalProps) {
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  if (!isOpen) return null;
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API delay
    setTimeout(() => {
      onConfirm(comment);
      setIsSubmitting(false);
      setComment('');
    }, 1000);
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose} />


      {/* Modal Card */}
      <div className="relative w-full max-w-md bg-[#111] border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-zinc-800">
          <h3 className="text-lg font-medium text-white">
            Подтверждение записи
          </h3>
          <button
            onClick={onClose}
            className="text-zinc-500 hover:text-white transition-colors">

            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <p className="text-zinc-400 text-sm mb-2">
              Вы записываетесь на секцию:
            </p>
            <p className="text-xl font-serif italic text-white">
              {sectionName}
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-xs uppercase tracking-wider text-zinc-500 font-medium">
              Комментарий (необязательно)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Ваши пожелания или вопросы..."
              className="w-full h-24 bg-zinc-900/50 border border-zinc-800 rounded-lg p-3 text-zinc-200 text-sm focus:outline-none focus:border-violet-500 transition-colors resize-none" />

          </div>

          <div className="flex gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1">

              Отмена
            </Button>
            <Button type="submit" isLoading={isSubmitting} className="flex-1">
              Подтвердить
            </Button>
          </div>
        </form>
      </div>
    </div>);

}