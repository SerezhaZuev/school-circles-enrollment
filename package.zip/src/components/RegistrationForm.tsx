import React, { useState } from 'react';
import { Input } from './ui/Input';
import { Button } from './ui/Button';
import { ArrowRight } from 'lucide-react';
interface RegistrationFormProps {
  onLogin?: (user: any) => void;
}
export function RegistrationForm({ onLogin }: RegistrationFormProps) {
  const [userType, setUserType] = useState<'participant' | 'organizer'>(
    'participant'
  );
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      if (onLogin) {
        onLogin({
          id: Math.random().toString(36).substr(2, 9),
          name: formData.name || 'Пользователь',
          email: formData.email,
          type: userType
        });
      }
    }, 1500);
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-12 relative z-10">
      {/* User Type Selection */}
      <div className="space-y-6">
        <div className="flex gap-8 pb-8 border-b border-zinc-800/50">
          <label className="relative cursor-pointer group">
            <input
              type="radio"
              name="type"
              className="sr-only"
              checked={userType === 'participant'}
              onChange={() => setUserType('participant')} />

            <div
              className={`flex items-center gap-3 transition-opacity duration-300 ${userType === 'participant' ? 'opacity-100' : 'opacity-40 group-hover:opacity-70'}`}>

              <div
                className={`w-4 h-4 border border-zinc-500 rounded-full flex items-center justify-center transition-colors ${userType === 'participant' ? 'border-violet-500' : ''}`}>

                {userType === 'participant' &&
                <div className="w-2 h-2 bg-violet-500 rounded-full" />
                }
              </div>
              <span className="text-sm tracking-widest uppercase text-zinc-200">
                Участник
              </span>
            </div>
          </label>

          <label className="relative cursor-pointer group">
            <input
              type="radio"
              name="type"
              className="sr-only"
              checked={userType === 'organizer'}
              onChange={() => setUserType('organizer')} />

            <div
              className={`flex items-center gap-3 transition-opacity duration-300 ${userType === 'organizer' ? 'opacity-100' : 'opacity-40 group-hover:opacity-70'}`}>

              <div
                className={`w-4 h-4 border border-zinc-500 rounded-full flex items-center justify-center transition-colors ${userType === 'organizer' ? 'border-violet-500' : ''}`}>

                {userType === 'organizer' &&
                <div className="w-2 h-2 bg-violet-500 rounded-full" />
                }
              </div>
              <span className="text-sm tracking-widest uppercase text-zinc-200">
                Организатор
              </span>
            </div>
          </label>
        </div>

        {/* Dynamic Helper Text */}
        <div className="h-8 transition-all duration-500 ease-out overflow-hidden">
          <p
            key={userType}
            className="text-xs text-violet-400/80 animate-in fade-in slide-in-from-top-2 duration-300">

            {userType === 'participant' ?
            'Как участник, вы получите доступ к записи на кружки и секции.' :
            'Как организатор, вы сможете создавать и управлять своими мероприятиями.'}
          </p>
        </div>
      </div>

      {/* Fields Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12">
        <Input
          label="Полное Имя"
          name="name"
          placeholder="Введите ваше имя"
          type="text"
          required
          value={formData.name}
          onChange={handleChange} />

        <Input
          label="Email Адрес"
          name="email"
          placeholder="name@example.com"
          type="email"
          required
          value={formData.email}
          onChange={handleChange} />

        <Input
          label="Пароль"
          name="password"
          placeholder="••••••••"
          type="password"
          required
          value={formData.password}
          onChange={handleChange} />

        <Input
          label="Подтвердите Пароль"
          name="confirmPassword"
          placeholder="••••••••"
          type="password"
          required
          value={formData.confirmPassword}
          onChange={handleChange} />

      </div>

      {/* Helper Text */}
      <div className="flex items-start gap-3 text-zinc-500 text-xs leading-relaxed max-w-md">
        <div className="w-1 h-1 rounded-full bg-zinc-700 mt-1.5 shrink-0" />
        <p>
          Пароль должен содержать минимум 8 символов, включая буквы и цифры.
        </p>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-8 pt-4">
        <Button
          type="submit"
          isLoading={isLoading}
          className="w-full sm:w-auto min-w-[200px]">

          Зарегистрироваться
        </Button>

        <a
          href="#/login"
          className="text-sm text-zinc-500 hover:text-violet-400 transition-colors flex items-center gap-2 group">

          Уже есть аккаунт?
          <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
        </a>
      </div>
    </form>);

}