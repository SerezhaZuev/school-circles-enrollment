import React from 'react';
import {
  Clock,
  Users,
  Calendar,
  MapPin,
  Edit2,
  Trash2,
  CheckCircle2 } from
'lucide-react';
interface SectionCardProps {
  id?: string;
  name: string;
  category: string;
  description: string;
  schedule: string;
  photo: string;
  status?: 'pending' | 'confirmed' | 'none';
  participantCount?: number;
  pendingCount?: number;
  isOrganizer?: boolean;
  location?: string;
  onAction: () => void;
  onDelete?: () => void;
}
export function SectionCard({
  id,
  name,
  category,
  description,
  schedule,
  photo,
  status = 'none',
  participantCount = 0,
  pendingCount = 0,
  isOrganizer = false,
  location,
  onAction,
  onDelete
}: SectionCardProps) {
  return (
    <article className="group relative bg-[#0d0d0d] border border-zinc-800/50 rounded-2xl overflow-hidden hover:border-zinc-700/50 transition-all duration-500 flex flex-col h-full">
      {/* Image Section */}
      <div className="relative h-48 overflow-hidden bg-zinc-900">
        <img
          src={photo}
          alt={name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />

        <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent opacity-60" />

        {/* Category Badge */}
        <div className="absolute top-4 left-4">
          <span className="inline-block px-3 py-1 rounded-full text-[10px] uppercase tracking-widest font-medium bg-black/40 backdrop-blur-md border border-white/10 text-white">
            {category}
          </span>
        </div>

        {/* Status Badge for Participants */}
        {status !== 'none' && !isOrganizer &&
        <div className="absolute top-4 right-4">
            <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] uppercase tracking-widest font-medium backdrop-blur-md border ${status === 'confirmed' ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/20 border-amber-500/30 text-amber-300'}`}>

              {status === 'confirmed' && <CheckCircle2 className="w-3 h-3" />}
              {status === 'confirmed' ? 'Подтверждено' : 'Ожидает'}
            </span>
          </div>
        }

        {/* Pending Count for Organizers */}
        {isOrganizer && pendingCount > 0 &&
        <div className="absolute top-4 right-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] uppercase tracking-widest font-medium bg-amber-500/20 backdrop-blur-md border border-amber-500/30 text-amber-300">
              {pendingCount} новых
            </span>
          </div>
        }
      </div>

      {/* Content Section */}
      <div className="flex-1 flex flex-col p-6">
        {/* Title */}
        <h3 className="text-lg font-medium text-white mb-2 line-clamp-2 group-hover:text-violet-300 transition-colors">
          {name}
        </h3>

        {/* Description */}
        <p className="text-sm text-zinc-500 leading-relaxed mb-4 line-clamp-2 flex-1">
          {description}
        </p>

        {/* Meta Info */}
        <div className="space-y-2 mb-6 pb-6 border-b border-zinc-800/50">
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <Clock className="w-3.5 h-3.5 text-zinc-600" />
            <span>{schedule}</span>
          </div>

          {location &&
          <div className="flex items-center gap-2 text-xs text-zinc-400">
              <MapPin className="w-3.5 h-3.5 text-zinc-600" />
              <span>{location}</span>
            </div>
          }

          {isOrganizer &&
          <div className="flex items-center gap-2 text-xs text-zinc-400">
              <Users className="w-3.5 h-3.5 text-zinc-600" />
              <span>{participantCount} участников</span>
            </div>
          }
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          {isOrganizer ?
          <>
              <button
              onClick={onAction}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 rounded-lg text-xs uppercase tracking-wider font-medium text-zinc-300 hover:text-white transition-all">

                <Edit2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Редактировать</span>
              </button>
              <button
              onClick={onDelete}
              className="px-4 py-2.5 bg-zinc-900 hover:bg-red-950/30 border border-zinc-800 hover:border-red-900/30 rounded-lg text-xs uppercase tracking-wider font-medium text-zinc-500 hover:text-red-400 transition-all">

                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </> :

          <button
            onClick={onAction}
            disabled={status !== 'none'}
            className={`w-full px-4 py-3 rounded-lg text-xs uppercase tracking-widest font-medium transition-all ${status !== 'none' ? 'bg-zinc-900 border border-zinc-800 text-zinc-600 cursor-not-allowed' : 'bg-violet-600 hover:bg-violet-700 text-white hover:shadow-lg hover:shadow-violet-500/20 border border-violet-500/20'}`}>

              {status === 'none' ? 'Записаться' : 'Заявка отправлена'}
            </button>
          }
        </div>
      </div>

      {/* Hover Glow Effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-t from-violet-500/5 via-transparent to-transparent" />
      </div>
    </article>);

}