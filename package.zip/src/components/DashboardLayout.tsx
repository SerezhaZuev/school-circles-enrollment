import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  LayoutGrid,
  Plus,
  User,
  LogOut,
  Calendar } from
'lucide-react';
interface DashboardLayoutProps {
  children: React.ReactNode;
  userType: 'participant' | 'organizer';
  activePage: string;
}
export function DashboardLayout({
  children,
  userType,
  activePage
}: DashboardLayoutProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);
  const navItems =
  userType === 'participant' ?
  [
  {
    id: 'home',
    label: 'Главная',
    icon: LayoutGrid,
    href: '#/dashboard-participant'
  },
  {
    id: 'sections',
    label: 'Секции',
    icon: Calendar,
    href: '#/sections'
  },
  {
    id: 'profile',
    label: 'Профиль',
    icon: User,
    href: '#/profile'
  }] :

  [
  {
    id: 'home',
    label: 'Главная',
    icon: LayoutGrid,
    href: '#/dashboard-organizer'
  },
  {
    id: 'my-sections',
    label: 'Мои секции',
    icon: Calendar,
    href: '#/my-sections'
  },
  {
    id: 'add',
    label: 'Добавить',
    icon: Plus,
    href: '#/add-section'
  },
  {
    id: 'profile',
    label: 'Профиль',
    icon: User,
    href: '#/profile'
  }];

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 relative overflow-hidden font-sans selection:bg-violet-500/30 selection:text-violet-200">
      {/* Background Noise & Gradients */}
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none z-0"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
        }} />

      <div className="fixed top-[-20%] right-[-10%] w-[800px] h-[800px] bg-violet-900/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-indigo-900/05 rounded-full blur-[100px] pointer-events-none" />

      {/* Grid Lines */}
      <div className="fixed inset-0 pointer-events-none z-0 flex justify-between px-6 md:px-12 lg:px-24">
        <div className="w-[1px] h-full bg-zinc-900/50" />
        <div className="w-[1px] h-full bg-zinc-900/50 hidden md:block" />
        <div className="w-[1px] h-full bg-zinc-900/50 hidden lg:block" />
        <div className="w-[1px] h-full bg-zinc-900/50" />
      </div>

      <div className="relative z-10 flex min-h-screen">
        {/* Sidebar Navigation */}
        <aside className="fixed left-0 top-0 bottom-0 w-20 lg:w-64 border-r border-zinc-800/50 bg-[#0a0a0a]/80 backdrop-blur-md z-50 flex flex-col justify-between py-8 px-4 lg:px-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-medium tracking-[0.2em] text-zinc-500 uppercase mb-12 pl-2">
              <span className="w-2 h-2 bg-violet-500 rounded-full" />
              <span className="hidden lg:inline">Цифровое Сообщество</span>
            </div>

            <nav className="space-y-2">
              {navItems.map((item) =>
              <a
                key={item.id}
                href={item.href}
                className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-300 group ${activePage === item.id ? 'bg-zinc-900 text-white' : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900/50'}`}>

                  <item.icon
                  className={`w-5 h-5 ${activePage === item.id ? 'text-violet-500' : 'text-zinc-600 group-hover:text-zinc-400'}`} />

                  <span className="hidden lg:block text-sm font-medium tracking-wide">
                    {item.label}
                  </span>
                  {activePage === item.id &&
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-violet-500 hidden lg:block" />
                }
                </a>
              )}
            </nav>
          </div>

          <button className="flex items-center gap-4 px-4 py-3 text-zinc-500 hover:text-red-400 transition-colors group">
            <LogOut className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            <span className="hidden lg:block text-sm font-medium tracking-wide">
              Выход
            </span>
          </button>
        </aside>

        {/* Main Content */}
        <main
          className={`flex-1 ml-20 lg:ml-64 p-6 md:p-12 lg:p-16 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>

          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>);

}