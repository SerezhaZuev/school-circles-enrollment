import React from 'react';
import { Loader2 } from 'lucide-react';
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline';
  isLoading?: boolean;
}
export function Button({
  children,
  variant = 'primary',
  isLoading,
  className = '',
  ...props
}: ButtonProps) {
  const baseStyles =
  'relative px-8 py-4 text-sm font-medium tracking-widest uppercase transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden group';
  const variants = {
    primary:
    'bg-violet-600 text-white hover:bg-violet-700 hover:shadow-[0_0_20px_rgba(124,58,237,0.3)]',
    outline:
    'border border-zinc-700 text-zinc-300 hover:border-zinc-500 hover:text-white bg-transparent'
  };
  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={isLoading}
      {...props}>

      <span className="relative z-10 flex items-center justify-center gap-2">
        {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
        {children}
      </span>
      {variant === 'primary' &&
      <div className="absolute inset-0 -translate-x-full group-hover:translate-x-0 bg-gradient-to-r from-violet-600 to-indigo-600 transition-transform duration-500 ease-out z-0" />
      }
    </button>);

}