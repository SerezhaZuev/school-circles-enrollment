import React from 'react';
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}
export function Input({ label, error, className = '', ...props }: InputProps) {
  return (
    <div className="group relative">
      <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider mb-2 group-focus-within:text-violet-400 transition-colors">
        {label}
      </label>
      <input
        className={`
          w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 
          px-0 py-3 placeholder-zinc-700 focus:outline-none focus:border-violet-500 
          transition-all duration-300 hover:border-zinc-700
          ${error ? 'border-red-500' : ''}
          ${className}
        `}
        {...props} />

      {error &&
      <span className="text-xs text-red-500 mt-1 absolute -bottom-5 left-0">
          {error}
        </span>
      }
      <div className="absolute bottom-0 left-0 w-0 h-[1px] bg-violet-500 transition-all duration-500 group-focus-within:w-full" />
    </div>);

}