import React, { useEffect, useState } from 'react';
import { RegistrationPage } from './pages/RegistrationPage';
import { LoginPage } from './pages/LoginPage';
import { ParticipantDashboard } from './pages/ParticipantDashboard';
import { OrganizerDashboard } from './pages/OrganizerDashboard';
import { SectionList } from './pages/SectionList';
import { MySections } from './pages/MySections';
import { AddSection } from './pages/AddSection';
import { EditSection } from './pages/EditSection';
import { Profile } from './pages/Profile';
import { SectionDetail } from './pages/SectionDetail';
// Types
export interface User {
  id: string;
  name: string;
  email: string;
  type: 'participant' | 'organizer';
}
export interface Section {
  id: string;
  name: string;
  category: string;
  description: string;
  schedule: string;
  ageGroup: string;
  organizerId: string;
  photo: string;
  participantCount: number;
  pendingCount?: number;
  location?: string;
  requirements?: string[];
}
export interface Enrollment {
  id: string;
  userId: string;
  sectionId: string;
  status: 'pending' | 'confirmed' | 'rejected';
  createdAt: string;
}
// Mock Data
const MOCK_SECTIONS: Section[] = [
{
  id: '1',
  name: 'Digital Art Workshop',
  category: 'Творчество',
  description:
  'Погружение в мир цифрового искусства. Изучаем композицию, цвет и современные инструменты.',
  schedule: 'Пн, Ср 18:00',
  ageGroup: '14-18 лет',
  organizerId: 'org1',
  photo:
  'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=2070',
  participantCount: 12,
  pendingCount: 3,
  location: 'Студия 404, ул. Ленина 15'
},
{
  id: '2',
  name: 'Робототехника Pro',
  category: 'Наука',
  description:
  'Создание и программирование сложных роботов на базе Arduino и Raspberry Pi.',
  schedule: 'Вт, Чт 16:30',
  ageGroup: '12-16 лет',
  organizerId: 'org2',
  photo:
  'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80&w=2070',
  participantCount: 8,
  pendingCount: 1,
  location: 'Лаборатория Tech Hub'
},
{
  id: '3',
  name: 'Street Dance Crew',
  category: 'Танцы',
  description:
  'Современные уличные танцы. Хип-хоп, брейк-данс и постановка хореографии.',
  schedule: 'Пт 19:00, Сб 14:00',
  ageGroup: '10-15 лет',
  organizerId: 'org1',
  photo:
  'https://images.unsplash.com/photo-1535525153412-5a42439a210d?auto=format&fit=crop&q=80&w=2070',
  participantCount: 20,
  pendingCount: 5,
  location: 'Танцевальная студия Move'
},
{
  id: '4',
  name: 'Школа Барабанов',
  category: 'Музыка',
  description: 'Освой ритм и технику игры на ударной установке с нуля.',
  schedule: 'Индивидуально',
  ageGroup: 'Любой возраст',
  organizerId: 'org3',
  photo:
  'https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?auto=format&fit=crop&q=80&w=2070',
  participantCount: 5,
  pendingCount: 0,
  location: 'Музыкальная школа Ритм'
}];

export function App() {
  const [route, setRoute] = useState(window.location.hash || '#/register');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [sections, setSections] = useState<Section[]>(MOCK_SECTIONS);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  useEffect(() => {
    const handleHashChange = () => {
      setRoute(window.location.hash || '#/register');
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);
  // Auth Handlers
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.type === 'participant') {
      window.location.hash = '#/dashboard-participant';
    } else {
      window.location.hash = '#/dashboard-organizer';
    }
  };
  const handleLogout = () => {
    setCurrentUser(null);
    window.location.hash = '#/login';
  };
  // Data Handlers
  const handleAddSection = (newSection: any) => {
    const section: Section = {
      ...newSection,
      id: Math.random().toString(36).substr(2, 9),
      organizerId: currentUser?.id || 'org1',
      participantCount: 0,
      pendingCount: 0
    };
    setSections([...sections, section]);
    window.location.hash = '#/my-sections';
  };
  const handleUpdateSection = (updatedSection: any) => {
    setSections(
      sections.map((s) =>
      s.id === updatedSection.id ?
      {
        ...s,
        ...updatedSection
      } :
      s
      )
    );
    window.location.hash = '#/my-sections';
  };
  const handleDeleteSection = (sectionId: string) => {
    setSections(sections.filter((s) => s.id !== sectionId));
  };
  const handleEnroll = (sectionId: string, comment: string) => {
    if (!currentUser) return;
    const newEnrollment: Enrollment = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      sectionId,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setEnrollments([...enrollments, newEnrollment]);
    // Update section pending count
    setSections(
      sections.map((s) =>
      s.id === sectionId ?
      {
        ...s,
        pendingCount: (s.pendingCount || 0) + 1
      } :
      s
      )
    );
  };
  // Router
  const renderPage = () => {
    const sectionIdMatch = route.match(/#\/section\/(.+)/);
    const editSectionIdMatch = route.match(/#\/edit-section\/(.+)/);
    if (sectionIdMatch) {
      const sectionId = sectionIdMatch[1];
      const enrollment = enrollments.find(
        (e) => e.sectionId === sectionId && e.userId === currentUser?.id
      );
      return (
        <SectionDetail
          sectionId={sectionId}
          userType={currentUser?.type || 'participant'}
          onBack={() => window.history.back()}
          onEnroll={handleEnroll}
          isEnrolled={!!enrollment}
          enrollmentStatus={enrollment?.status} />);


    }
    if (editSectionIdMatch) {
      return (
        <EditSection
          sectionId={editSectionIdMatch[1]}
          onSave={handleUpdateSection}
          onCancel={() => window.history.back()} />);


    }
    switch (route) {
      case '#/login':
        return <LoginPage onLogin={handleLogin} />;
      case '#/register':
        return <RegistrationPage onLogin={handleLogin} />;
      case '#/dashboard-participant':
        return (
          <ParticipantDashboard
            user={currentUser}
            sections={sections}
            enrollments={enrollments} />);


      case '#/dashboard-organizer':
        return <OrganizerDashboard user={currentUser} sections={sections} />;
      case '#/my-sections':
        return <MySections sections={sections} organizerId={currentUser?.id} />;
      case '#/sections':
        return (
          <SectionList
            userType={currentUser?.type || 'participant'}
            sections={sections} />);


      case '#/add-section':
        return (
          <AddSection
            onSave={handleAddSection}
            onCancel={() => window.history.back()} />);


      case '#/profile':
        return <Profile user={currentUser} onLogout={handleLogout} />;
      default:
        return <RegistrationPage onLogin={handleLogin} />;
    }
  };
  return <>{renderPage()}</>;
}