import React, { useEffect, useState } from 'react';
import { RegistrationForm } from '../components/RegistrationForm';
import { ArrowUpRight, Asterisk } from 'lucide-react';
interface RegistrationPageProps {
  onLogin?: (user: any) => void;
}
export function RegistrationPage({ onLogin }: RegistrationPageProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 relative overflow-hidden selection:bg-violet-500/30 selection:text-violet-200 font-sans">
      {/* Background Noise & Gradients */}
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none z-0"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
        }} />

      <div className="fixed top-[-20%] right-[-10%] w-[800px] h-[800px] bg-violet-900/20 rounded-full blur-[120px] pointer-events-none animate-pulse-slow" />
      <div className="fixed bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-indigo-900/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Grid Lines (Decorative) */}
      <div className="fixed inset-0 pointer-events-none z-0 flex justify-between px-6 md:px-12 lg:px-24">
        <div className="w-[1px] h-full bg-zinc-900/50" />
        <div className="w-[1px] h-full bg-zinc-900/50 hidden md:block" />
        <div className="w-[1px] h-full bg-zinc-900/50 hidden lg:block" />
        <div className="w-[1px] h-full bg-zinc-900/50" />
      </div>

      {/* Main Layout */}
      <main className="relative z-10 min-h-screen flex flex-col lg:flex-row">
        {/* Left Column: Hero / Context */}
        <div className="lg:w-5/12 p-6 md:p-12 lg:p-24 flex flex-col justify-between relative">
          {/* Header */}
          <header
            className={`transition-all duration-1000 delay-100 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>

            <div className="flex items-center gap-3 text-xs font-medium tracking-[0.2em] text-zinc-500 uppercase mb-8">
              <span className="w-2 h-2 bg-violet-500 rounded-full animate-pulse" />
              Цифровое Сообщество
            </div>
            <h1 className="text-5xl md:text-7xl font-light leading-[0.9] tracking-tight text-white mb-6">
              Присоединяйся <br />
              <span className="font-serif italic text-zinc-400">
                к движению.
              </span>
            </h1>
            <p className="text-zinc-500 max-w-xs leading-relaxed text-sm border-l border-zinc-800 pl-4 mt-8">
              Доступ к эксклюзивным мастер-классам, творческим сессиям и
              сообществу прогрессивных организаторов.
            </p>
          </header>

          {/* Decorative Number */}
          <div
            className={`hidden lg:block absolute bottom-24 left-24 transition-all duration-1000 delay-300 ${mounted ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>

            <span className="text-[12rem] leading-none font-bold text-zinc-900/50 select-none font-serif">
              01
            </span>
          </div>

          {/* Mobile Footer */}
          <div className="lg:hidden mt-12 flex items-center gap-4 text-xs text-zinc-600">
            <span>ОСН. 2024</span>
            <div className="h-px w-8 bg-zinc-800" />
            <span>ГЛОБАЛЬНЫЙ ДОСТУП</span>
          </div>
        </div>

        {/* Right Column: Form */}
        <div className="lg:w-7/12 p-6 md:p-12 lg:p-24 flex items-center relative">
          {/* Floating Card Background */}
          <div
            className={`absolute inset-0 bg-zinc-900/30 backdrop-blur-sm lg:rounded-l-[3rem] border-t lg:border-l border-zinc-800/50 transition-all duration-1000 ease-out ${mounted ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}`} />


          <div
            className={`w-full max-w-xl mx-auto relative z-10 transition-all duration-1000 delay-500 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>

            <div className="mb-12 flex items-end justify-between">
              <h2 className="text-2xl font-light tracking-wide">
                Создать Аккаунт
              </h2>
              <Asterisk className="w-6 h-6 text-violet-500 animate-spin-slow" />
            </div>

            <RegistrationForm onLogin={onLogin} />

            <div className="mt-16 pt-8 border-t border-zinc-800/50 flex justify-between items-center text-xs text-zinc-600 uppercase tracking-wider">
              <span>Защищённое Шифрование</span>
              <div className="flex gap-4">
                <a href="#" className="hover:text-zinc-400 transition-colors">
                  Конфиденциальность
                </a>
                <a href="#" className="hover:text-zinc-400 transition-colors">
                  Условия
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Floating UI Elements */}
      <div className="fixed top-8 right-8 z-50 hidden md:flex gap-2">
        <button className="w-10 h-10 rounded-full border border-zinc-800 flex items-center justify-center text-zinc-500 hover:text-white hover:border-zinc-600 transition-all">
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </div>);

}