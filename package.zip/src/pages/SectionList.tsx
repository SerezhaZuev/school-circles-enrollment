import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { SectionCard } from '../components/SectionCard';
import { Search, SlidersHorizontal, Filter } from 'lucide-react';
const ALL_SECTIONS = [
{
  id: 1,
  title: 'Цифровая Фотография',
  category: 'Искусство',
  description:
  'Изучите основы композиции, работы со светом и постобработки в профессиональных редакторах.',
  schedule: 'Пн, Ср 18:00',
  image:
  'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?auto=format&fit=crop&q=80&w=800',
  status: 'none' as const
},
{
  id: 2,
  title: 'Веб-Разработка Pro',
  category: 'IT',
  description:
  'Продвинутый курс по React, TypeScript и современной фронтенд разработке.',
  schedule: 'Вт, Чт 19:00',
  image:
  'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=800',
  status: 'pending' as const
},
{
  id: 3,
  title: 'Керамика и Дизайн',
  category: 'Ремесло',
  description:
  'Создание авторской керамики, работа с гончарным кругом и глазурью.',
  schedule: 'Сб 12:00',
  image:
  'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&q=80&w=800',
  status: 'confirmed' as const
},
{
  id: 4,
  title: 'Sound Design',
  category: 'Музыка',
  description:
  'Создание звуковых ландшафтов, синтез звука и работа в Ableton Live.',
  schedule: 'Пт 18:30',
  image:
  'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=800',
  status: 'none' as const
},
{
  id: 5,
  title: '3D Моделирование',
  category: 'IT',
  description:
  'Основы Blender и Maya. Создание персонажей и окружения для игр.',
  schedule: 'Ср, Пт 17:00',
  image:
  'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800',
  status: 'none' as const
},
{
  id: 6,
  title: 'Современный Танец',
  category: 'Спорт',
  description:
  'Развитие пластики, чувства ритма и импровизации. Contemporary dance.',
  schedule: 'Вт, Чт 20:00',
  image:
  'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=800',
  status: 'none' as const
}];

export function SectionList() {
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const filteredSections = ALL_SECTIONS.filter((section) => {
    const matchesCategory = filter === 'all' || section.category === filter;
    const matchesSearch =
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });
  return (
    <DashboardLayout userType="participant" activePage="sections">
      {/* Header */}
      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl md:text-5xl font-light mb-4">
            Все{' '}
            <span className="text-violet-400 font-serif italic">Секции</span>
          </h1>
          <p className="text-zinc-500 max-w-lg font-light">
            Исследуйте полный каталог доступных направлений. От технологий до
            искусства.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-zinc-600 uppercase tracking-widest">
          <span>Всего доступно</span>
          <div className="h-px w-8 bg-zinc-800" />
          <span className="text-zinc-300">{filteredSections.length}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="sticky top-0 z-30 bg-[#0a0a0a]/95 backdrop-blur-xl border-y border-zinc-800/50 py-4 mb-12 -mx-6 px-6 md:-mx-12 md:px-12 lg:-mx-16 lg:px-16 transition-all">
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto no-scrollbar">
            {['Все', 'IT', 'Искусство', 'Музыка', 'Спорт', 'Ремесло'].map(
              (cat) =>
              <button
                key={cat}
                onClick={() => setFilter(cat === 'Все' ? 'all' : cat)}
                className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider border transition-all whitespace-nowrap ${filter === 'all' && cat === 'Все' || filter === cat ? 'bg-violet-500/10 border-violet-500/50 text-violet-300' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600 hover:text-zinc-300'}`}>

                  {cat}
                </button>

            )}
          </div>

          <div className="flex gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <input
                type="text"
                placeholder="Поиск..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-10 pr-4 py-2 text-sm text-zinc-300 focus:outline-none focus:border-violet-500 transition-colors" />

            </div>
            <button className="p-2 border border-zinc-800 rounded-lg text-zinc-500 hover:text-white hover:border-zinc-600 transition-colors">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
        {filteredSections.map((section) =>
        <SectionCard
          key={section.id}
          {...section}
          onAction={() => console.log('Register for', section.title)} />

        )}
      </div>

      {filteredSections.length === 0 &&
      <div className="text-center py-24 border border-dashed border-zinc-800 rounded-2xl">
          <p className="text-zinc-500 mb-2">Ничего не найдено</p>
          <button
          onClick={() => {
            setFilter('all');
            setSearchQuery('');
          }}
          className="text-violet-400 hover:text-violet-300 text-sm underline">

            Сбросить фильтры
          </button>
        </div>
      }
    </DashboardLayout>);

}