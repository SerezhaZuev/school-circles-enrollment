import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { User, Mail, Shield, Key } from 'lucide-react';
export function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [userType] = useState<'participant' | 'organizer'>('participant'); // In real app, get from context
  return (
    <DashboardLayout userType={userType} activePage="profile">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-12 flex items-end justify-between">
          <div>
            <h1 className="text-3xl md:text-5xl font-light mb-4">
              Личный{' '}
              <span className="text-violet-400 font-serif italic">Профиль</span>
            </h1>
            <p className="text-zinc-500 max-w-lg font-light">
              Управляйте своими данными и настройками безопасности.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="w-24 h-24 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-2xl font-serif italic text-zinc-500">
              AL
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-zinc-900/30 border border-zinc-800/50 p-8 relative overflow-hidden">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-lg font-medium tracking-wide flex items-center gap-2">
                  <User className="w-4 h-4 text-violet-500" />
                  Основная Информация
                </h3>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="text-xs uppercase tracking-wider text-zinc-500 hover:text-violet-400 transition-colors">

                  {isEditing ? 'Отменить' : 'Редактировать'}
                </button>
              </div>

              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Input
                    label="Имя"
                    defaultValue="Алекс"
                    disabled={!isEditing}
                    className={
                    !isEditing ? 'opacity-50 cursor-not-allowed' : ''
                    } />

                  <Input
                    label="Фамилия"
                    defaultValue="Петров"
                    disabled={!isEditing}
                    className={
                    !isEditing ? 'opacity-50 cursor-not-allowed' : ''
                    } />

                </div>
                <Input
                  label="Email"
                  defaultValue="alex@example.com"
                  disabled={!isEditing}
                  className={!isEditing ? 'opacity-50 cursor-not-allowed' : ''} />

                <div className="pt-4">
                  <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider mb-2">
                    О себе
                  </label>
                  <textarea
                    rows={3}
                    disabled={!isEditing}
                    className={`w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 px-0 py-3 focus:outline-none focus:border-violet-500 transition-all resize-none ${!isEditing ? 'opacity-50 cursor-not-allowed' : ''}`}
                    defaultValue="Увлекаюсь фотографией и веб-дизайном. Ищу интересные курсы для развития навыков." />

                </div>

                {isEditing &&
                <div className="flex justify-end pt-4">
                    <Button>Сохранить изменения</Button>
                  </div>
                }
              </div>
            </div>

            {/* Security */}
            <div className="bg-zinc-900/30 border border-zinc-800/50 p-8">
              <h3 className="text-lg font-medium tracking-wide flex items-center gap-2 mb-8">
                <Shield className="w-4 h-4 text-violet-500" />
                Безопасность
              </h3>

              <div className="flex items-center justify-between py-4 border-b border-zinc-800/50">
                <div>
                  <p className="text-sm font-medium text-zinc-200">Пароль</p>
                  <p className="text-xs text-zinc-500 mt-1">
                    Последнее изменение 3 месяца назад
                  </p>
                </div>
                <button className="text-xs uppercase tracking-wider text-zinc-500 hover:text-white transition-colors border border-zinc-800 px-4 py-2 hover:border-zinc-600">
                  Сменить
                </button>
              </div>

              <div className="flex items-center justify-between py-4 pt-6">
                <div>
                  <p className="text-sm font-medium text-zinc-200">
                    Двухфакторная аутентификация
                  </p>
                  <p className="text-xs text-zinc-500 mt-1">
                    Дополнительный уровень защиты аккаунта
                  </p>
                </div>
                <div className="w-10 h-5 bg-zinc-800 rounded-full relative cursor-pointer">
                  <div className="w-3 h-3 bg-zinc-600 rounded-full absolute top-1 left-1" />
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar Stats */}
          <div className="space-y-6">
            <div className="bg-violet-900/10 border border-violet-500/20 p-6">
              <p className="text-xs uppercase tracking-widest text-violet-400 mb-2">
                Статус Аккаунта
              </p>
              <p className="text-xl font-light text-white">Активный Участник</p>
            </div>

            <div className="bg-zinc-900/30 border border-zinc-800/50 p-6">
              <p className="text-xs uppercase tracking-widest text-zinc-500 mb-4">
                Статистика
              </p>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-400">Активные записи</span>
                  <span className="text-white font-mono">3</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-400">
                    Завершено курсов
                  </span>
                  <span className="text-white font-mono">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-400">Часов обучения</span>
                  <span className="text-white font-mono">48</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>);

}