import React from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { SectionCard } from '../components/SectionCard';
import { Plus, Users, CheckCircle, Clock } from 'lucide-react';
import { Button } from '../components/ui/Button';
const MY_SECTIONS = [
{
  id: 1,
  title: 'Основы Робототехники',
  category: 'Технологии',
  description: 'Конструирование и программирование роботов на базе Arduino.',
  schedule: 'Пн, Ср 16:00',
  image:
  'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80&w=800',
  participantsCount: 12,
  pendingCount: 3
},
{
  id: 2,
  title: '3D Моделирование',
  category: 'Design',
  description: 'Создание трехмерных моделей в Blender для игр и печати.',
  schedule: 'Вт, Чт 18:00',
  image:
  'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=800',
  participantsCount: 8,
  pendingCount: 0
}];

const APPLICATIONS = [
{
  id: 1,
  name: 'Иван Петров',
  age: 14,
  section: 'Основы Робототехники',
  date: '2 часа назад'
},
{
  id: 2,
  name: 'Мария Сидорова',
  age: 15,
  section: 'Основы Робототехники',
  date: '5 часов назад'
},
{
  id: 3,
  name: 'Алексей Волков',
  age: 13,
  section: 'Основы Робототехники',
  date: '1 день назад'
}];

export function OrganizerDashboard() {
  return (
    <DashboardLayout userType="organizer" activePage="home">
      {/* Hero Section */}
      <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between mb-16 gap-8">
        <div>
          <h1 className="text-4xl md:text-6xl font-light mb-4">
            Панель{' '}
            <span className="text-violet-400 font-serif italic">
              Организатора
            </span>
          </h1>
          <p className="text-zinc-500 max-w-xl text-lg font-light">
            Управляйте своими секциями, просматривайте заявки и следите за
            статистикой.
          </p>
        </div>

        <Button className="shrink-0">
          <Plus className="w-4 h-4 mr-2" />
          Добавить Секцию
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {[
        {
          label: 'Активных секций',
          value: '2',
          icon: CheckCircle
        },
        {
          label: 'Всего участников',
          value: '20',
          icon: Users
        },
        {
          label: 'Новых заявок',
          value: '3',
          icon: Clock,
          highlight: true
        }].
        map((stat, i) =>
        <div
          key={i}
          className="bg-zinc-900/30 border border-zinc-800/50 p-6 relative overflow-hidden group">

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs uppercase tracking-widest text-zinc-500">
                  {stat.label}
                </span>
                <stat.icon
                className={`w-5 h-5 ${stat.highlight ? 'text-amber-400' : 'text-zinc-600'}`} />

              </div>
              <div className="text-4xl font-light text-white">{stat.value}</div>
            </div>
            <div
            className={`absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-500 ${stat.highlight ? 'from-amber-500 to-orange-600' : 'from-violet-500 to-indigo-600'}`} />

          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* My Sections */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex items-center justify-between border-b border-zinc-800/50 pb-4">
            <h2 className="text-xl font-light">Мои Секции</h2>
            <a
              href="#/my-sections"
              className="text-xs uppercase tracking-widest text-zinc-500 hover:text-white transition-colors">

              Показать все
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {MY_SECTIONS.map((section) =>
            <SectionCard
              key={section.id}
              {...section}
              isOrganizer
              onAction={() => console.log('Edit', section.title)} />

            )}
          </div>
        </div>

        {/* Recent Applications */}
        <div className="space-y-8">
          <div className="flex items-center justify-between border-b border-zinc-800/50 pb-4">
            <h2 className="text-xl font-light">Новые Заявки</h2>
            <span className="text-xs bg-amber-900/30 text-amber-400 px-2 py-1 rounded-full">
              3
            </span>
          </div>

          <div className="space-y-4">
            {APPLICATIONS.map((app) =>
            <div
              key={app.id}
              className="bg-zinc-900/30 border border-zinc-800/50 p-4 hover:border-zinc-700 transition-colors group">

                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="text-sm font-medium text-white group-hover:text-violet-300 transition-colors">
                      {app.name}
                    </h4>
                    <p className="text-xs text-zinc-500">
                      {app.age} лет • {app.section}
                    </p>
                  </div>
                  <span className="text-[10px] text-zinc-600">{app.date}</span>
                </div>

                <div className="flex gap-2 mt-4">
                  <button className="flex-1 py-1.5 bg-zinc-800 hover:bg-emerald-900/30 text-zinc-400 hover:text-emerald-400 text-[10px] uppercase tracking-wider transition-colors">
                    Принять
                  </button>
                  <button className="flex-1 py-1.5 bg-zinc-800 hover:bg-red-900/30 text-zinc-400 hover:text-red-400 text-[10px] uppercase tracking-wider transition-colors">
                    Отклонить
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>);

}