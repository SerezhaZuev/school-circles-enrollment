import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Upload, Calendar, Clock, MapPin } from 'lucide-react';
export function AddSection() {
  const [isLoading, setIsLoading] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      window.location.hash = '#/dashboard-organizer';
    }, 1500);
  };
  return (
    <DashboardLayout userType="organizer" activePage="add">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-3xl md:text-5xl font-light mb-4">
            Новая{' '}
            <span className="text-violet-400 font-serif italic">Секция</span>
          </h1>
          <p className="text-zinc-500 max-w-lg font-light">
            Заполните информацию о вашем мероприятии, чтобы привлечь участников.
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-zinc-900/30 border border-zinc-800/50 backdrop-blur-sm p-8 md:p-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-violet-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

          <form onSubmit={handleSubmit} className="space-y-12 relative z-10">
            {/* Image Upload */}
            <div className="w-full aspect-[21/9] bg-zinc-900/50 border-2 border-dashed border-zinc-800 hover:border-violet-500/50 transition-colors rounded-lg flex flex-col items-center justify-center cursor-pointer group">
              <div className="p-4 rounded-full bg-zinc-800 group-hover:bg-violet-500/20 text-zinc-500 group-hover:text-violet-400 transition-all mb-4">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm text-zinc-400 font-medium">
                Загрузить обложку
              </p>
              <p className="text-xs text-zinc-600 mt-2">PNG, JPG до 5MB</p>
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Input
                label="Название Секции"
                placeholder="Например: Курс по фотографии"
                required />

              <div className="space-y-2">
                <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider mb-2">
                  Категория
                </label>
                <select className="w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 px-0 py-3 focus:outline-none focus:border-violet-500 transition-all">
                  <option>IT и Программирование</option>
                  <option>Искусство и Дизайн</option>
                  <option>Музыка</option>
                  <option>Спорт</option>
                  <option>Языки</option>
                </select>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider mb-2">
                Описание
              </label>
              <textarea
                rows={4}
                className="w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 px-0 py-3 placeholder-zinc-700 focus:outline-none focus:border-violet-500 transition-all resize-none"
                placeholder="Расскажите подробнее о программе, требованиях и результатах..." />

            </div>

            {/* Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="relative">
                <Calendar className="absolute right-0 top-8 w-4 h-4 text-zinc-600" />
                <Input label="Расписание" placeholder="Пн, Ср 18:00" required />
              </div>
              <div className="relative">
                <Clock className="absolute right-0 top-8 w-4 h-4 text-zinc-600" />
                <Input label="Длительность" placeholder="1.5 часа" required />
              </div>
              <div className="relative">
                <MapPin className="absolute right-0 top-8 w-4 h-4 text-zinc-600" />
                <Input label="Локация" placeholder="Онлайн / Адрес" required />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-6 pt-6 border-t border-zinc-800/50">
              <button
                type="button"
                className="text-sm text-zinc-500 hover:text-white transition-colors">

                Отмена
              </button>
              <Button type="submit" isLoading={isLoading}>
                Создать Секцию
              </Button>
            </div>
          </form>
        </div>
      </div>
    </DashboardLayout>);

}