import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Button } from '../components/ui/Button';
import { EnrollmentModal } from '../components/EnrollmentModal';
import {
  ArrowLeft,
  Calendar,
  Users,
  Clock,
  MapPin,
  CheckCircle } from
'lucide-react';
// Mock data interface (should match App.tsx)
interface Section {
  id: string;
  name: string;
  category: string;
  description: string;
  schedule: string;
  ageGroup: string;
  organizerId: string;
  photo: string;
  participantCount: number;
  location?: string;
  requirements?: string[];
}
interface SectionDetailProps {
  sectionId: string;
  userType: 'participant' | 'organizer';
  onBack: () => void;
  onEnroll?: (sectionId: string, comment: string) => void;
  isEnrolled?: boolean;
  enrollmentStatus?: 'pending' | 'confirmed' | 'rejected';
}
// Mock section data for fallback/demo
const MOCK_SECTION: Section = {
  id: '1',
  name: 'Digital Art Workshop',
  category: 'Творчество',
  description:
  'Погружение в мир цифрового искусства. Мы изучим основы композиции, работу с цветом и современные инструменты для создания digital-иллюстраций. Курс подходит как для новичков, так и для тех, кто хочет улучшить свои навыки.',
  schedule: 'Пн, Ср 18:00',
  ageGroup: '14-18 лет',
  organizerId: 'org1',
  photo:
  'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=2070',
  participantCount: 12,
  location: 'Студия 404, ул. Ленина 15',
  requirements: [
  'Свой ноутбук',
  'Графический планшет (желательно)',
  'Базовые навыки рисования']

};
export function SectionDetail({
  sectionId,
  userType,
  onBack,
  onEnroll,
  isEnrolled = false,
  enrollmentStatus
}: SectionDetailProps) {
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  // In a real app, we would fetch the section by ID here
  // For now using mock data
  const section = MOCK_SECTION;
  const handleEnroll = (comment: string) => {
    if (onEnroll) {
      onEnroll(sectionId, comment);
      setIsEnrollModalOpen(false);
    }
  };
  return (
    <DashboardLayout userType={userType} activePage="sections">
      <div className="max-w-5xl mx-auto">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-zinc-500 hover:text-white transition-colors mb-8 group">

          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm uppercase tracking-wider">
            Назад к списку
          </span>
        </button>

        {/* Hero Section */}
        <div className="relative rounded-3xl overflow-hidden mb-12 border border-zinc-800/50 group">
          <div className="aspect-[21/9] w-full relative">
            <img
              src={section.photo}
              alt={section.name}
              className="w-full h-full object-cover" />

            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-transparent" />
          </div>

          <div className="absolute bottom-0 left-0 p-8 md:p-12 w-full">
            <div className="flex items-center gap-3 mb-4">
              <span className="px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 text-xs uppercase tracking-wider border border-violet-500/20">
                {section.category}
              </span>
              <span className="px-3 py-1 rounded-full bg-zinc-800/50 text-zinc-400 text-xs uppercase tracking-wider border border-zinc-700/50">
                {section.ageGroup}
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-light text-white mb-4 leading-tight">
              {section.name}
            </h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <section>
              <h2 className="text-xl font-light text-white mb-6 flex items-center gap-3">
                <span className="w-8 h-[1px] bg-violet-500" />О секции
              </h2>
              <p className="text-zinc-400 leading-relaxed text-lg">
                {section.description}
              </p>
            </section>

            {section.requirements &&
            <section>
                <h2 className="text-xl font-light text-white mb-6 flex items-center gap-3">
                  <span className="w-8 h-[1px] bg-violet-500" />
                  Требования
                </h2>
                <ul className="space-y-3">
                  {section.requirements.map((req, i) =>
                <li
                  key={i}
                  className="flex items-start gap-3 text-zinc-400">

                      <CheckCircle className="w-5 h-5 text-violet-500/50 shrink-0 mt-0.5" />
                      {req}
                    </li>
                )}
                </ul>
              </section>
            }
          </div>

          {/* Sidebar Info */}
          <div className="space-y-6">
            <div className="bg-[#111] border border-zinc-800 rounded-2xl p-6 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800 text-violet-400">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">
                      Расписание
                    </p>
                    <p className="text-zinc-200">{section.schedule}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800 text-violet-400">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">
                      Локация
                    </p>
                    <p className="text-zinc-200">
                      {section.location || 'Онлайн / Уточняется'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800 text-violet-400">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">
                      Участники
                    </p>
                    <p className="text-zinc-200">
                      {section.participantCount} человек
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-zinc-800">
                {userType === 'participant' ?
                isEnrolled ?
                <div className="w-full py-4 bg-zinc-900 border border-zinc-800 rounded-lg text-center">
                      <p className="text-sm text-zinc-400 mb-1">
                        Статус заявки
                      </p>
                      <p
                    className={`text-lg font-medium ${enrollmentStatus === 'confirmed' ? 'text-green-400' : enrollmentStatus === 'rejected' ? 'text-red-400' : 'text-violet-400'}`}>

                        {enrollmentStatus === 'confirmed' ?
                    'Подтверждено' :
                    enrollmentStatus === 'rejected' ?
                    'Отклонено' :
                    'Ожидает подтверждения'}
                      </p>
                    </div> :

                <Button
                  className="w-full"
                  onClick={() => setIsEnrollModalOpen(true)}>

                      Записаться
                    </Button> :


                <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" className="w-full">
                      Редактировать
                    </Button>
                    <Button
                    variant="outline"
                    className="w-full text-red-400 hover:text-red-300 hover:border-red-900">

                      Удалить
                    </Button>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      </div>

      <EnrollmentModal
        isOpen={isEnrollModalOpen}
        onClose={() => setIsEnrollModalOpen(false)}
        onConfirm={handleEnroll}
        sectionName={section.name} />

    </DashboardLayout>);

}