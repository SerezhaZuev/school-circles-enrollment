import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { ArrowLeft, Upload, Image as ImageIcon } from 'lucide-react';
interface EditSectionProps {
  sectionId: string;
  onSave: (data: any) => void;
  onCancel: () => void;
}
export function EditSection({ sectionId, onSave, onCancel }: EditSectionProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Творчество',
    description: '',
    schedule: '',
    ageGroup: '',
    photo: ''
  });
  // Simulate fetching data
  useEffect(() => {
    // In real app, fetch by ID
    setFormData({
      name: 'Digital Art Workshop',
      category: 'Творчество',
      description: 'Погружение в мир цифрового искусства...',
      schedule: 'Пн, Ср 18:00',
      ageGroup: '14-18 лет',
      photo: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f'
    });
  }, [sectionId]);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onSave({
        ...formData,
        id: sectionId
      });
      setIsLoading(false);
    }, 1500);
  };
  return (
    <DashboardLayout userType="organizer" activePage="sections">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={onCancel}
          className="flex items-center gap-2 text-zinc-500 hover:text-white transition-colors mb-8 group">

          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm uppercase tracking-wider">Отмена</span>
        </button>

        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-light text-white mb-2">
            Редактировать секцию
          </h1>
          <p className="text-zinc-500">
            Обновите информацию о вашем мероприятии
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-8 bg-[#111] border border-zinc-800 p-8 rounded-2xl relative overflow-hidden">

          {/* Decorative Glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-violet-900/10 blur-[80px] rounded-full pointer-events-none" />

          <div className="space-y-6 relative z-10">
            <Input
              label="Название секции"
              value={formData.name}
              onChange={(e) =>
              setFormData({
                ...formData,
                name: e.target.value
              })
              }
              required />


            <div className="space-y-2">
              <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider">
                Категория
              </label>
              <select
                className="w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 py-3 focus:outline-none focus:border-violet-500 transition-colors appearance-none rounded-none"
                value={formData.category}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  category: e.target.value
                })
                }>

                <option>Творчество</option>
                <option>Спорт</option>
                <option>Наука</option>
                <option>Языки</option>
                <option>Музыка</option>
                <option>Танцы</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider">
                Описание
              </label>
              <textarea
                className="w-full bg-zinc-900/50 border-b border-zinc-800 text-zinc-100 py-3 min-h-[120px] focus:outline-none focus:border-violet-500 transition-colors resize-none rounded-none"
                value={formData.description}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  description: e.target.value
                })
                }
                required />

            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Расписание"
                value={formData.schedule}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  schedule: e.target.value
                })
                }
                placeholder="Напр: Пн, Ср 18:00"
                required />

              <Input
                label="Возрастная группа"
                value={formData.ageGroup}
                onChange={(e) =>
                setFormData({
                  ...formData,
                  ageGroup: e.target.value
                })
                }
                placeholder="Напр: 14-18 лет"
                required />

            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-zinc-500 uppercase tracking-wider mb-2">
                Фотография
              </label>
              <div className="border border-dashed border-zinc-700 rounded-lg p-8 flex flex-col items-center justify-center text-zinc-500 hover:border-violet-500 hover:text-violet-400 transition-colors cursor-pointer group bg-zinc-900/30">
                {formData.photo ?
                <div className="relative w-full h-48 rounded overflow-hidden">
                    <img
                    src={formData.photo}
                    alt="Preview"
                    className="w-full h-full object-cover" />

                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="text-white text-sm">Изменить фото</span>
                    </div>
                  </div> :

                <>
                    <Upload className="w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
                    <span className="text-sm">
                      Нажмите чтобы загрузить фото
                    </span>
                  </>
                }
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4 border-t border-zinc-800">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="flex-1">

              Отмена
            </Button>
            <Button type="submit" isLoading={isLoading} className="flex-1">
              Сохранить
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>);

}