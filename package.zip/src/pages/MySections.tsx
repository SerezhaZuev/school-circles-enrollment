import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { SectionCard } from '../components/SectionCard';
import { Plus, Search, Filter } from 'lucide-react';
import { Button } from '../components/ui/Button';
interface MySectionsProps {
  sections: any[];
  organizerId?: string;
}
export function MySections({
  sections,
  organizerId = 'org1'
}: MySectionsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  // Filter sections by current organizer
  const mySections = sections.filter((s) => s.organizerId === organizerId);
  const filteredSections = mySections.filter((section) =>
  section.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  return (
    <DashboardLayout userType="organizer" activePage="my-sections">
      {/* Header */}
      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl md:text-5xl font-light mb-4">
            Мои{' '}
            <span className="text-violet-400 font-serif italic">Секции</span>
          </h1>
          <p className="text-zinc-500 max-w-lg font-light">
            Управляйте своими мероприятиями, редактируйте информацию и следите
            за заявками.
          </p>
        </div>

        <Button onClick={() => window.location.hash = '#/add-section'}>
          <Plus className="w-4 h-4 mr-2" />
          Создать секцию
        </Button>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
        <div className="bg-zinc-900/30 border border-zinc-800/50 p-6 rounded-xl">
          <p className="text-xs uppercase tracking-widest text-zinc-500 mb-2">
            Всего секций
          </p>
          <p className="text-3xl font-light text-white">{mySections.length}</p>
        </div>
        <div className="bg-zinc-900/30 border border-zinc-800/50 p-6 rounded-xl">
          <p className="text-xs uppercase tracking-widest text-zinc-500 mb-2">
            Участников
          </p>
          <p className="text-3xl font-light text-white">
            {mySections.reduce((sum, s) => sum + s.participantCount, 0)}
          </p>
        </div>
        <div className="bg-zinc-900/30 border border-zinc-800/50 p-6 rounded-xl">
          <p className="text-xs uppercase tracking-widest text-zinc-500 mb-2">
            Новых заявок
          </p>
          <p className="text-3xl font-light text-amber-400">
            {mySections.reduce((sum, s) => sum + (s.pendingCount || 0), 0)}
          </p>
        </div>
        <div className="bg-zinc-900/30 border border-zinc-800/50 p-6 rounded-xl">
          <p className="text-xs uppercase tracking-widest text-zinc-500 mb-2">
            Активных
          </p>
          <p className="text-3xl font-light text-emerald-400">
            {mySections.length}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            placeholder="Поиск по названию..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-sm text-zinc-300 focus:outline-none focus:border-violet-500 transition-colors" />

        </div>
      </div>

      {/* Sections Grid */}
      {filteredSections.length > 0 ?
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSections.map((section) =>
        <SectionCard
          key={section.id}
          {...section}
          isOrganizer
          onAction={() =>
          window.location.hash = `#/edit-section/${section.id}`
          } />

        )}
        </div> :

      <div className="text-center py-24 border border-dashed border-zinc-800 rounded-2xl">
          <div className="max-w-sm mx-auto">
            <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4">
              <Plus className="w-8 h-8 text-zinc-600" />
            </div>
            <h3 className="text-xl font-light text-white mb-2">
              {searchQuery ? 'Ничего не найдено' : 'Нет созданных секций'}
            </h3>
            <p className="text-zinc-500 mb-6">
              {searchQuery ?
            'Попробуйте изменить поисковый запрос' :
            'Создайте свою первую секцию, чтобы начать привлекать участников'}
            </p>
            {!searchQuery &&
          <Button onClick={() => window.location.hash = '#/add-section'}>
                <Plus className="w-4 h-4 mr-2" />
                Создать первую секцию
              </Button>
          }
          </div>
        </div>
      }
    </DashboardLayout>);

}