import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { SectionCard } from '../components/SectionCard';
import { Search, SlidersHorizontal } from 'lucide-react';
const MOCK_SECTIONS = [
{
  id: 1,
  title: 'Цифровая Фотография',
  category: 'Искусство',
  description:
  'Изучите основы композиции, работы со светом и постобработки в профессиональных редакторах.',
  schedule: 'Пн, Ср 18:00',
  image:
  'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?auto=format&fit=crop&q=80&w=800',
  status: 'none'
},
{
  id: 2,
  title: 'Веб-Разработка Pro',
  category: 'IT',
  description:
  'Продвинутый курс по React, TypeScript и современной фронтенд разработке.',
  schedule: 'Вт, Чт 19:00',
  image:
  'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=800',
  status: 'pending'
},
{
  id: 3,
  title: 'Керамика и Дизайн',
  category: 'Ремесло',
  description:
  'Создание авторской керамики, работа с гончарным кругом и глазурью.',
  schedule: 'Сб 12:00',
  image:
  'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&q=80&w=800',
  status: 'confirmed'
},
{
  id: 4,
  title: 'Sound Design',
  category: 'Музыка',
  description:
  'Создание звуковых ландшафтов, синтез звука и работа в Ableton Live.',
  schedule: 'Пт 18:30',
  image:
  'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=800',
  status: 'none'
}];

export function ParticipantDashboard() {
  const [filter, setFilter] = useState('all');
  return (
    <DashboardLayout userType="participant" activePage="home">
      {/* Hero Section */}
      <div className="mb-16 relative">
        <h1 className="text-4xl md:text-6xl font-light mb-4">
          Привет,{' '}
          <span className="text-violet-400 font-serif italic">Алекс</span>
        </h1>
        <p className="text-zinc-500 max-w-xl text-lg font-light">
          Найди свой кружок или секцию. Выбирай по интересам, записывайся и
          развивай навыки.
        </p>

        <div className="absolute right-0 top-0 hidden lg:block opacity-20">
          <span className="text-9xl font-serif font-bold text-zinc-800 select-none">
            01
          </span>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row gap-6 mb-12 items-start md:items-center justify-between border-b border-zinc-800/50 pb-8">
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto no-scrollbar">
          {['Все', 'IT', 'Искусство', 'Музыка', 'Спорт'].map((cat) =>
          <button
            key={cat}
            onClick={() => setFilter(cat === 'Все' ? 'all' : cat)}
            className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider border transition-all whitespace-nowrap ${filter === 'all' && cat === 'Все' || filter === cat ? 'bg-violet-500/10 border-violet-500/50 text-violet-300' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600 hover:text-zinc-300'}`}>

              {cat}
            </button>
          )}
        </div>

        <div className="flex gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Поиск секций..."
              className="w-full bg-zinc-900/50 border border-zinc-800 rounded-lg pl-10 pr-4 py-2 text-sm text-zinc-300 focus:outline-none focus:border-violet-500 transition-colors" />

          </div>
          <button className="p-2 border border-zinc-800 rounded-lg text-zinc-500 hover:text-white hover:border-zinc-600 transition-colors">
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {MOCK_SECTIONS.map((section) =>
        <SectionCard
          key={section.id}
          {...section}
          onAction={() => console.log('Register for', section.title)} />

        )}
      </div>
    </DashboardLayout>);

}