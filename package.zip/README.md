# Установка зависимостей
npm install

# Запуск в режиме разработки
npm run dev  # Сервер на http://localhost:5173

# Сборка для продакшена
npm run build

# Предпросмотр сборки
npm run preview